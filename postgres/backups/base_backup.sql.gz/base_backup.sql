--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2 (Debian 11.2-1.pgdg90+1)
-- Dumped by pg_dump version 11.2 (Debian 11.2-1.pgdg90+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.user_registery DROP CONSTRAINT user_registery_fk_players_id_fkey;
ALTER TABLE ONLY public.server_registery DROP CONSTRAINT server_registery_fk_servers_id_fkey;
ALTER TABLE ONLY public.server_registery DROP CONSTRAINT server_registery_fk_players_id_fkey;
ALTER TABLE ONLY public.user_registery DROP CONSTRAINT user_registery_pkey;
ALTER TABLE ONLY public.user_registery DROP CONSTRAINT user_registery_discord_id_key;
ALTER TABLE ONLY public.servers DROP CONSTRAINT servers_server_id_key;
ALTER TABLE ONLY public.servers DROP CONSTRAINT servers_pkey;
ALTER TABLE ONLY public.server_registery DROP CONSTRAINT server_registery_pkey;
ALTER TABLE ONLY public.players DROP CONSTRAINT players_pubg_id_key;
ALTER TABLE ONLY public.players DROP CONSTRAINT players_pkey;
ALTER TABLE public.user_registery ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.servers ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.server_registery ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.players ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.user_registery_id_seq;
DROP TABLE public.user_registery;
DROP SEQUENCE public.servers_id_seq;
DROP TABLE public.servers;
DROP SEQUENCE public.server_registery_id_seq;
DROP TABLE public.server_registery;
DROP SEQUENCE public.players_id_seq;
DROP TABLE public.players;
SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: players; Type: TABLE; Schema: public; Owner: pubg-buddy
--

CREATE TABLE public.players (
    id integer NOT NULL,
    pubg_id text,
    username text,
    platform text
);


ALTER TABLE public.players OWNER TO "pubg-buddy";

--
-- Name: players_id_seq; Type: SEQUENCE; Schema: public; Owner: pubg-buddy
--

CREATE SEQUENCE public.players_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.players_id_seq OWNER TO "pubg-buddy";

--
-- Name: players_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pubg-buddy
--

ALTER SEQUENCE public.players_id_seq OWNED BY public.players.id;


--
-- Name: server_registery; Type: TABLE; Schema: public; Owner: pubg-buddy
--

CREATE TABLE public.server_registery (
    id integer NOT NULL,
    fk_players_id integer,
    fk_servers_id integer
);


ALTER TABLE public.server_registery OWNER TO "pubg-buddy";

--
-- Name: server_registery_id_seq; Type: SEQUENCE; Schema: public; Owner: pubg-buddy
--

CREATE SEQUENCE public.server_registery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.server_registery_id_seq OWNER TO "pubg-buddy";

--
-- Name: server_registery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pubg-buddy
--

ALTER SEQUENCE public.server_registery_id_seq OWNED BY public.server_registery.id;


--
-- Name: servers; Type: TABLE; Schema: public; Owner: pubg-buddy
--

CREATE TABLE public.servers (
    id integer NOT NULL,
    server_id text,
    default_bot_prefix text DEFAULT '!pubg-'::text,
    default_region text DEFAULT 'PC_NA'::text,
    default_mode text DEFAULT 'SQUAD_FPP'::text
);


ALTER TABLE public.servers OWNER TO "pubg-buddy";

--
-- Name: servers_id_seq; Type: SEQUENCE; Schema: public; Owner: pubg-buddy
--

CREATE SEQUENCE public.servers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.servers_id_seq OWNER TO "pubg-buddy";

--
-- Name: servers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pubg-buddy
--

ALTER SEQUENCE public.servers_id_seq OWNED BY public.servers.id;


--
-- Name: user_registery; Type: TABLE; Schema: public; Owner: pubg-buddy
--

CREATE TABLE public.user_registery (
    id integer NOT NULL,
    discord_id text,
    fk_players_id integer
);


ALTER TABLE public.user_registery OWNER TO "pubg-buddy";

--
-- Name: user_registery_id_seq; Type: SEQUENCE; Schema: public; Owner: pubg-buddy
--

CREATE SEQUENCE public.user_registery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_registery_id_seq OWNER TO "pubg-buddy";

--
-- Name: user_registery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: pubg-buddy
--

ALTER SEQUENCE public.user_registery_id_seq OWNED BY public.user_registery.id;


--
-- Name: players id; Type: DEFAULT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.players ALTER COLUMN id SET DEFAULT nextval('public.players_id_seq'::regclass);


--
-- Name: server_registery id; Type: DEFAULT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.server_registery ALTER COLUMN id SET DEFAULT nextval('public.server_registery_id_seq'::regclass);


--
-- Name: servers id; Type: DEFAULT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.servers ALTER COLUMN id SET DEFAULT nextval('public.servers_id_seq'::regclass);


--
-- Name: user_registery id; Type: DEFAULT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.user_registery ALTER COLUMN id SET DEFAULT nextval('public.user_registery_id_seq'::regclass);


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: pubg-buddy
--

COPY public.players (id, pubg_id, username, platform) FROM stdin;
\.


--
-- Data for Name: server_registery; Type: TABLE DATA; Schema: public; Owner: pubg-buddy
--

COPY public.server_registery (id, fk_players_id, fk_servers_id) FROM stdin;
\.


--
-- Data for Name: servers; Type: TABLE DATA; Schema: public; Owner: pubg-buddy
--

COPY public.servers (id, server_id, default_bot_prefix, default_region, default_mode) FROM stdin;
\.


--
-- Data for Name: user_registery; Type: TABLE DATA; Schema: public; Owner: pubg-buddy
--

COPY public.user_registery (id, discord_id, fk_players_id) FROM stdin;
\.


--
-- Name: players_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pubg-buddy
--

SELECT pg_catalog.setval('public.players_id_seq', 1, false);


--
-- Name: server_registery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pubg-buddy
--

SELECT pg_catalog.setval('public.server_registery_id_seq', 1, false);


--
-- Name: servers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pubg-buddy
--

SELECT pg_catalog.setval('public.servers_id_seq', 1, false);


--
-- Name: user_registery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: pubg-buddy
--

SELECT pg_catalog.setval('public.user_registery_id_seq', 1, false);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: players players_pubg_id_key; Type: CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pubg_id_key UNIQUE (pubg_id);


--
-- Name: server_registery server_registery_pkey; Type: CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.server_registery
    ADD CONSTRAINT server_registery_pkey PRIMARY KEY (id);


--
-- Name: servers servers_pkey; Type: CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_pkey PRIMARY KEY (id);


--
-- Name: servers servers_server_id_key; Type: CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.servers
    ADD CONSTRAINT servers_server_id_key UNIQUE (server_id);


--
-- Name: user_registery user_registery_discord_id_key; Type: CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.user_registery
    ADD CONSTRAINT user_registery_discord_id_key UNIQUE (discord_id);


--
-- Name: user_registery user_registery_pkey; Type: CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.user_registery
    ADD CONSTRAINT user_registery_pkey PRIMARY KEY (id);


--
-- Name: server_registery server_registery_fk_players_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.server_registery
    ADD CONSTRAINT server_registery_fk_players_id_fkey FOREIGN KEY (fk_players_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: server_registery server_registery_fk_servers_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.server_registery
    ADD CONSTRAINT server_registery_fk_servers_id_fkey FOREIGN KEY (fk_servers_id) REFERENCES public.servers(id) ON DELETE CASCADE;


--
-- Name: user_registery user_registery_fk_players_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: pubg-buddy
--

ALTER TABLE ONLY public.user_registery
    ADD CONSTRAINT user_registery_fk_players_id_fkey FOREIGN KEY (fk_players_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

